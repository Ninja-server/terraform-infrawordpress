#!/bin/bash

sudo su
curl -O https://wordpress.org/latest.tar.gz
tar -xzf latest.tar.gz



